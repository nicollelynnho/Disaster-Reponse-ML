#run from in model directory
import sys
from sqlalchemy import create_engine
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.pipeline import Pipeline
import nltk
#nltk.download('punkt')
#nltk.download(['punkt', 'wordnet', 'averaged_perceptron_tagger'])
from sklearn.metrics import classification_report
import pickle
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin


def load_data(database_filepath):
    '''load data from database into target and feature variables
    Parameters: database file path
    Returns: feature variable, target variable, category names'''
    df = pd.read_sql_table('data/DisasterResponse', database_filepath)
    X = df.message.values
    Y = df.drop(['id','message','original'],axis=1).values
    category_names = df.drop(['id','message','original'],axis=1).columns.values
    return X, Y, category_names


def tokenize(text):
    '''Separates sentences into individual words.
    Parameters: str sentence
    Returns: array of individual words (tokens)'''
    return nltk.word_tokenize(text)

def reshape(rr):
    '''transposes array
    Parameters: array
    Returns: array'''
    new = []
    for i in range(37):
        col = []
        for j in range(len(rr)):
            col.append(rr[j][i])
        new.append(col)
    return new

def build_model():
    '''Builds the model using transformer, random forest, and MultiOutput classifer
    Parameters: None
    Returns: model'''
    #vect = CountVectorizer(tokenizer=tokenize)
    #tfidf = TfidfTransformer()
    forest = RandomForestClassifier()
    clf = MultiOutputClassifier(forest, n_jobs=1)
    #pipeline = Pipeline([('vect', vect), ('tfidf', tfidf), ('clf', clf)])

    pipeline = Pipeline([
        ('features', FeatureUnion([

            ('text_pipeline', Pipeline([
                ('vect', CountVectorizer(tokenizer=tokenize)),
                ('tfidf', TfidfTransformer())
            ]))
        ])),

        ('clf', clf)
    ])


    param_grid = {
        'clf__estimator__min_samples_leaf': [2,3,4],
        'clf__estimator__n_jobs': [100,200,300]
        }
    cv = GridSearchCV(pipeline, param_grid=param_grid)

    parameters = {
        'features__text_pipeline__vect__ngram_range': ((1, 1), (1, 2)),
    }

    cv = GridSearchCV(pipeline, param_grid=parameters)
    return cv

def evaluate_model(model, X_test, Y_test, category_names):
    '''evaluates predictions vs actuals for all classification categories
    parameters: model object, training data, test data, category genre_names
    Returns: None
    '''
    y_pred = model.predict(X_test)
    y_pred = reshape(y_pred)
    Y_test = reshape(Y_test)
    for i,name in zip(range(len(y_pred)),category_names):
        print(name)
        print(classification_report(Y_test[i], y_pred[i]))
        print('')
    pass


def save_model(model, model_filepath):
    '''Save Model to pickle file
    Parameters: model, str model file path
    Return: None'''
    with open(model_filepath, 'wb') as file:
        pickle.dump(model, file)
    pass


def main():
    if len(sys.argv) == 3:
        database_filepath, model_filepath = sys.argv[1:]
        print('Loading data...\n    DATABASE: {}'.format(database_filepath))
        X, Y, category_names = load_data(database_filepath)
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

        print('Building model...')
        model = build_model()

        print('Training model...')
        model.fit(X_train, Y_train)
        print(model.best_params_)

        print('Evaluating model...')
        evaluate_model(model, X_test, Y_test, category_names)

        print('Saving model...\n    MODEL: {}'.format(model_filepath))
        save_model(model, model_filepath)

        print('Trained model saved!')

    else:
        print('Please provide the filepath of the disaster messages database '\
              'as the first argument and the filepath of the pickle file to '\
              'save the model to as the second argument. \n\nExample: python '\
              'train_classifier.py ../data/DisasterResponse.db classifier.pkl')


if __name__ == '__main__':
    main()
